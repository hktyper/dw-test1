#!/bin/bash
# Convenience script to quickly reset the watermark for a table
# Example usage:
# $ reset_watermark.sh dev hddw DBAT ADROAC
#
# WARNING!!
# Parameters are case sensitive and are not validated, so make sure you check everything!

ENV=$1
DB=$2
SCHEMA=$3
TABLE=$4

DTAB=${ENV}-dms-alternative-high-watermarks
KEY=\{\"TableKey\":\{\"S\":\"${ENV}/${DB}.${SCHEMA}.${TABLE}\"\}\}

echo -e "Deleting entry for $KEY from $DTAB"

aws dynamodb delete-item \
  --table-name "${DTAB}" \
  --key "${KEY}"

# ASPIRE Database Migration Service

## Contents
- [Purpose](#purpose)
- [Design](#design)
- [Usage](#usage)
- [Subscribing to Notifications Service](#subscribing-to-the-notifications-service)
- [Deployment](#deployment)

## Purpose
This service replicates data from an Oracle on-prem database to S3 as CSV files using two services:
- [AWS Database Migration Service](https://aws.amazon.com/dms/)
- [ASPIRE Argos Warehouse Extractor](https://github.com/sainsburys-tech/aspire-argos-warehouse-extractor) 
  (Python app, AKA DMS Alternative)

These services were primarily designed for replicating databases out of the Argos on-prem
data centre in Park Farm, but can be adapted to other use cases.

## Design
### AWS Database Migration Service
AWS DMS is deployed to a single VPC across any number of subnets.

This service will create:
- The VPC, subnets and security groups
- Source endpoints for Oracle databases
- Target endpoints for S3
- Replication Instances (one per task)
- Replication tasks with a defined list of tables to extract
- Alarms for when the source latency on the AWS DMS service is too high

The tasks and tables are defined in a simple YAML file:
[sources.yml](terraform/configs/sources.yml)

### Target S3 Endpoints
The name of the target S3 bucket is derived using the following formula:

| Data classification | Bucket name                                   | Example                                |
| ------------------- | --------------------------------------------- | -------------------------------------- |
| pii                 | `grada-pii-prd-src-raw-argos-dwh-<source db>` | `grada-pii-prd-src-raw-argos-dwh-hddw` |
| no-pii              | `dpp2-prd-raw-src-argos-dwh-<source db>`      | `dpp2-prd-raw-src-argos-dwh-midas`     |

### ASPIRE Argos Warehouse Extractor

This service will create:
- AMI with Packer and Ansible
- EC2 instance to run the Python app
- Cron job which runs the app daily at 6:30am
- Alarms for when there is no data for RowsLoaded metric

Tables can be configured to run by adding them to the orchestration template
[config_orch.yaml.j2](ansible/templates/config_orch.yaml.j2)

The Cloudwatch Alarms for the tables are defined in a simple YAML file:
[dms_alternative_sources.yml](terraform/configs/dms_alternative_sources.yml)

### Notifications Service

Confluence page for this service [here](https://sainsburys-confluence.valiantys.net/pages/viewpage.action?spaceKey=APPLE&title=DMS+Notifications).
All notifications from any files landed are pushed to a central SNS topic called `<env>-enriched-s3-notifications`. This
acts as a "one-stop-shop" for consuming services and decouples them from the underlying S3 buckets as much as possible.

The messages in this topic are standard SNS messages, but have additional message attributes added to them to allow subscribers
to apply subscription policies.

e.g.
```json
{
  "MessageAttributes" : {
    "Table" : {"Type":"String","Value":"DSSLDS"},
    "Bucket" : {"Type":"String","Value":"dpp-dev-raw-src-argos-dwh-midas"},
    "SourceSystem" : {"Type":"String","Value":"midas"},
    "Key" : {"Type":"String","Value":"csv-extracts/DBAP/DSSLDS/20210407-053007-0000.csv"}
  }
}
```

The original S3 notification can be found as a string value in the `Message` key, should it still be required.

### ADMI SQL Server

This service will create:
- S3 bucket with SNS topic
- SNS topic subscription for the Lambda enricher for the notifications service

## Usage

### Configuration
**AWS Database Migration Service**

Add tasks and tables to [sources.yml](terraform/configs/sources.yml). Source and target
endpoints are usually predefined and the details will be picked up from AWS Secrets Manager
using the key you specify in the YAML file.

Example:
```yaml
deployments:
    tasks:
      - hddw-task-1:
          source_db: hddw  # maps to Secrets Manager using <env>/<source_db> as the key
    
          migration_type: full-load-and-cdc # choose from full-load-and-cdc|full-load|cdc
          
          classification: non-pii # this determines what bucket (pii or non-pii) your data lands into
    
          instance_type: # must be a dms instance type, not just a regular EC2 type
            dev: dms.t2.medium
            preprod: dms.t2.medium
            prod: dms.c4.large  # more tables require more power!
    
          tables: # add as many tables here as you like, but beware you don't overload your instance
          - schema_name: # Schema can be different between environments
              dev: DBAT
              preprod: DBAT
              prod: DBAP
            table_name: ADRITM
            filters: # Filters are "AND"-ed together
              - column: MIS_START_DATE
                conditions:
                  - operator: gte
                    value: "2015-01-01"
          - schema_name:
              dev: DBAT
              preprod: DBAT
              prod: DBAP
            table_name: ADRLOC
            filters: [ ] # you need to specify an empty filter if you don't want filtering
```

**ASPIRE Argos Warehouse Extractor**

Add tables to [dms_alternative_sources.yml](terraform/configs/dms_alternative_sources.yml). 

Example:
```yaml
---
sources:
  hddw:
    - schema:
        dev: DBAT
        preprod: DBAT
        prod: DBAP
      table: ADRLOC
    - schema:
        dev: DBAT
        preprod: DBAT
        prod: DBAP
      table: ADRITM
```

### Subscribing to the Notifications Service
To add a new account to the SNS topic access policy, put the IAM ARN of the entity in the `subscriber_arns`
variable in the [locals.tf](./terraform/locals.tf) file.

This repo uses Terraform workspaces to manage environments so ensure the ARN is put under the correct environment key 
in the map.

If you need to add a new account variable, add it to the map aws_accounts in the 
[terraform.tfvars](./terraform/terraform.tfvars) file.

This repo is deployed using CircleCI - [see details below](#deployment). Please ask the Apple squad to deploy any 
changes to production! The pipeline will attempt to stop any running DMS tasks before deployment, 
but this is a little flaky at the moment and may give you an error. 

You can speak to us in the following Slack channel: [#data-apple-dms](https://sainsburys-tech.slack.com/archives/C01DNCRFU8G)

## Deployment

There is a CircleCI pipeline for terraform infrastructure changes. 
Building the AMI is manual and must be done locally.

### Artifacts Bucket
The `artifacts_bucket` sub-folder has it's own state and needs to be deployed manually before you run the main stack.
It should be a one-off exercise. Code from the [https://github.com/sainsburys-tech/aspire-dms-lambda-functions](aspire-dms-lambda-functions)
repo will be deployed here under a different pipeline. The main DMS stack relies on this code being available, otherwise
the Lambda deployment will fail.

### Packer

**Pre-requisites**

Ensure Packer and Ansible are installed locally

Confirm if packer is already installed

    packer --version

Confirm if ansible is already installed

    packer --version

If Packer is not installed follow instructions;

    brew tap hashicorp/tap

    brew install hashicorp/tap/packer

If Ansible is not installed follow instructions;

    brew install ansible

Ansible holds and preserves environment as a special variable

Copy your sainbury's tech repo SSH private key to tne ansible files directory

    cp $SAINSBURYS_TECH_REPO_PRIV_KEY_PATH $GIT_CODE_HOME/dms-aspire-infrastructure-terraform/ansible/files/id_rsa

    i.e.

    cp ~/.ssh/my_private_key ~/Code/dms-aspire-infrastructure-terraform/ansible/files/id_rsa

Execute packer build for the AMI:

    From the ./ansible directory:
    
    packer build -var 'account=$ENVIRONMENT' ../packer/packer.json
    
    i.e.

    packer build -var 'account=$ENVIRONMENT' ../packer/packer.json

    whereby $ENVIRONMENT == dev || preprod || prod

### Terraform

The accompanying CircleCI pipeline will validate each push to any non-master branch
by executing a `terraform plan`. The project will eventually be configured to only
test branches that have a PR raised against them.

There is the option to approve a deployment of this branch to `dev` but please mention it in the Slack
channel before you do this so you don't blow away anyone else's changes!

Slack channel: [#data-apple-dms](https://sainsburys-tech.slack.com/archives/C01DNCRFU8G)

After merging to master, the following pipeline executes against `dev`:
 - `terraform plan` is run again
 - all tasks running in `dev` are stopped, 
 - `terraform apply` is executed
 - all `dev` connections are tested

If the above passes, the pipeline continues on to `preprod`:
 - `terraform plan` is run against `preprod`
 - all tasks running in `preprod` are stopped
 - `terraform apply` is executed
 - all `preprod` connections are tested
 - all `preprod` tasks are restarted
 - tasks are checked to make sure they start successfully
 - all `preprod` tasks are shut down
 
If `preprod` passes testing, then we are good to deploy to production:
 - **The tasks in prod must be STOPPED before deployment**
 - There is a manual approval before production deployment
 - `terraform plan` is run against `prod`
 - all tasks impacted by the `plan` are stopped
 - `terraform apply` is executed
 - all impacted `prod` tasks are restarted
 - tasks are checked to make sure they start successfully
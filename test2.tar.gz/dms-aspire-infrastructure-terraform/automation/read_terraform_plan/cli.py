from automation.read_terraform_plan.constants import MAINARG_PLANFILE


def setup_cli():
    import argparse

    parser = argparse.ArgumentParser()

    parser.add_argument(
        type=str,
        dest=MAINARG_PLANFILE,
        help="Input Terraform Plan file in a human-readable format (as output by `terraform show`)."
    )

    return parser


def read_cli(preexisting_parser=None):
    parser = preexisting_parser or setup_cli()
    known, unknown = parser.parse_known_args()
    return vars(known)

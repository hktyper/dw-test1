import os

CURRENT_DIR = os.path.dirname(__file__)

DEFAULT_PLAN_FILE_NAME = "deployment-dev-update-tasks.json"
DEFAULT_PLAN_FILE = os.path.join(CURRENT_DIR, DEFAULT_PLAN_FILE_NAME)

PLAN_KEY_RESOURCE_CHANGES = 'resource_changes'

RESOURCE_KEY_CHANGE = "change"
RESOURCE_KEY_ADDRESS = "address"

CHANGE_KEY_ACTIONS = "actions"
CHANGE_KEY_BEFORE = "before"
CHANGE_KEY_AFTER = "after"

ACTION_CREATE = "create"
ACTION_READ = "read"
ACTION_UPDATE = "update"
ACTION_DELETE = "delete"
ACTION_NOOP = "no-op"

SUPPORTED_ACTION_TYPES = {
    ACTION_CREATE,
    ACTION_UPDATE,
    ACTION_READ,
    ACTION_DELETE,
    ACTION_NOOP,
}

KEYS_START_ACTION = {ACTION_UPDATE, ACTION_CREATE}
KEYS_STOP_ACTION = {ACTION_UPDATE, ACTION_DELETE}

DMS_TASK_ADDRESS = "module.replication_tasks.aws_dms_replication_task.dms_task"

MAINARG_PLANFILE = "plan_file"
import os
import site
import json
import typing

site.addsitedir(
    # I hate this hack *so* much... but it's still necessary -_-
    # two dirs up from the current location, so the automation scripts dir
    os.path.dirname(os.path.dirname(os.path.dirname(
        __file__
    )))
)

from automation.common.logs import logger
from automation.read_terraform_plan.cli import read_cli
from automation.read_terraform_plan import constants as const


def read_json(json_file: str) -> dict:
    with open(json_file) as f:
        json_plan = json.load(f)
    return json_plan


def sort_resource_changes(json_plan: dict) -> typing.Dict[str, typing.List[tuple]]:
    changes = json_plan[const.PLAN_KEY_RESOURCE_CHANGES]
    all_changes = {}

    for resource in changes:
        resource_address = resource[const.RESOURCE_KEY_ADDRESS]
        change_data = resource[const.RESOURCE_KEY_CHANGE]
        actions = change_data[const.CHANGE_KEY_ACTIONS]
        new_state = change_data.get(const.CHANGE_KEY_AFTER) or change_data[const.CHANGE_KEY_BEFORE]

        for action in actions:
            all_changes.setdefault(action, []).append((resource_address, new_state))

            if action not in const.SUPPORTED_ACTION_TYPES:
                logger.error(f"Found unexpected action type key: `{action}`")

    return all_changes


def find_tasks(change_list: typing.Iterable[tuple]) -> typing.Dict[str, dict]:
    matching_tasks = {
        task_address: new_state
        for task_address, new_state in change_list
        if const.DMS_TASK_ADDRESS in task_address
    }
    return matching_tasks


def get_resource_changes(plan_file: str) -> typing.Dict[str, typing.List[tuple]]:
    plan = read_json(json_file=plan_file)
    resource_changes = sort_resource_changes(plan)
    return resource_changes


def get_tasks(
    action_keys: typing.Iterable[str],
    resource_changes: typing.Optional[typing.Dict[str, typing.List[tuple]]] = None,
    plan_file: typing.Optional[str] = None,
    **kwargs
) -> typing.Dict[str, dict]:

    resource_changes = resource_changes or get_resource_changes(plan_file=plan_file)
    tasks = {}

    for action in action_keys:
        action_tasks = find_tasks(resource_changes.get(action) or {})
        tasks.update(action_tasks)

    return tasks


def main(**kwargs):
    _plan_file = kwargs[const.MAINARG_PLANFILE]

    resource_changes = get_resource_changes(plan_file=_plan_file)

    stop = get_tasks(
        action_keys=const.KEYS_STOP_ACTION,
        resource_changes=resource_changes
    )

    start = get_tasks(
        action_keys=const.KEYS_START_ACTION,
        resource_changes=resource_changes
    )

    logger.info(f"Tasks to be stopped: {tuple(stop)} \nTasks to be started: {tuple(start)}")
    return stop, start


if __name__ == "__main__":
    cli_args = read_cli()
    main(**cli_args)

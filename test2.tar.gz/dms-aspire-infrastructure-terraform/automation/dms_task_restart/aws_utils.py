import boto3

from automation.dms_task_restart import constants as const


def get_dms_client() -> object:
    dms_client = boto3.client(const.AWS_CLIENT_DMS)
    return dms_client


def get_all_tasks(*args, **kwargs) -> dict:
    describe_tasks_kwargs = kwargs.copy()
    dms_client = (
        describe_tasks_kwargs.pop(const.KEY_DMS_CONNECTION)
        if const.KEY_DMS_CONNECTION in describe_tasks_kwargs
        else get_dms_client()
    )

    response = dms_client.describe_replication_tasks(**describe_tasks_kwargs)

    task_data = response[const.AWS_DMS_KEY_REPLICATION_TASKS]
    all_tasks = {
        task[const.AWS_DMS_KEY_REPLICATION_TASK_IDENTIFIER]: {
            const.KEY_REPLICATION_TASK_ARN: task[const.AWS_DMS_KEY_REPLICATION_TASK_ARN]
        }
        for task in task_data
    }

    return all_tasks


import functools
import time
from unittest import mock as mock

from automation.common.logs import logger
from automation.dms_task_restart import constants as const


def exponential_backoff(retry_delay, curr_idx):
    _retry_delay = max(retry_delay, 0)
    run_delay = 0

    if retry_delay > 0 and curr_idx > 0:
        # if curr_idx <= 0, it's the first try - no point in waiting
        adjusted_idx = max(curr_idx-1, 0)
        run_delay = (2 ** (adjusted_idx)) * _retry_delay

    return run_delay


def retry_failed(
    max_attempts=None,
    retry_delay=None,
    task_key=None,
    log_statuses=False,
    fancy_logging=None
):

    _retry_count = max((max_attempts or const.DEFAULT_RETRY_COUNT), 0)
    _retry_delay = max((retry_delay or const.DEFAULT_RETRY_DELAY), 0)
    _task_key = task_key or const.DEFAULT_TASK_KEY
    _fancy_logging = fancy_logging or const.DEFAULT_FANCY_LOGS

    def _retry_deco(func):

        @functools.wraps(func)
        def _retry_wrapper(**raw_kwargs):
            pending = raw_kwargs[_task_key].copy()
            run_successes = {}
            run_failures = {}
            retries = 0

            kwargs = raw_kwargs.copy()
            if log_statuses:
                if _fancy_logging:
                    logger.info(''.center(const.LOG_SEPARATOR_LENGTH, "="))
                logger.info(f"Initiating retry loop for {func.__name__}()")

            while pending and retries <= _retry_count:
                if _fancy_logging:
                    logger.info(f"-" * const.LOG_SEPARATOR_LENGTH)
                logger.info(f"Try #{retries}")

                if retries > 0:
                    wait_time = exponential_backoff(_retry_delay, retries)
                    logger.info(f"Backoff time: {wait_time}s")
                    time.sleep(wait_time)

                retries += 1
                kwargs[_task_key] = pending
                try_successes, try_failures = func(**kwargs)

                for pending_task in pending.copy():

                    if pending_task in try_successes:
                        # move successes out of the temporary variable
                        run_successes[pending_task] = try_successes[pending_task]
                        pending.pop(pending_task)
                        if log_statuses:
                            logger.info(f"SUCCESS: {pending_task}: {try_successes[pending_task]}")

                    elif pending_task in try_failures:
                        # log all the new failures, for diagnostics
                        (run_failures
                         .setdefault(pending_task, [])
                         .extend(try_failures[pending_task])
                         )
                        if log_statuses:
                            logger.info(f"FAILURE: {pending_task}: {try_failures[pending_task]}")

                    else:
                        raise RuntimeError(
                            f"Invalid state: `{pending_task}` somehow neither successful nor failed"
                        )

            return run_successes, run_failures

        return _retry_wrapper

    return _retry_deco


def mock_dms_client(enabled=True):
    """Decorates a DMS client constructor function, returning a mock instead.
    The original constructor is *NOT* called, so the functionality of the logic
    downstream mustn't rely on any side-effects invoked by the decorated function.
    """

    def _mock_dms_deco(func):
        @functools.wraps(func)
        def _dms_faker_wrapper(*args, **kwargs):
            dms_client = mock.MagicMock()
            return dms_client

        return _dms_faker_wrapper if enabled else func

    return _mock_dms_deco

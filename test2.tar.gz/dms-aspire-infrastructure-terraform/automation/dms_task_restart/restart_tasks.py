import os
import site
import pprint


site.addsitedir(
    # I hate this hack *so* much... but it's still necessary -_-
    # two dirs up from the current location, so the automation scripts dir
    os.path.dirname(os.path.dirname(os.path.dirname(
        __file__
    )))
)

from automation.common.logs import logger
from automation.dms_task_restart import constants as const
from automation.dms_task_restart.actions import ACTION_MAP, TASK_FINDER_MAP
from automation.dms_task_restart.cli import read_cli
from automation.dms_task_restart.decorators import retry_failed, mock_dms_client
from automation.dms_task_restart import aws_utils


def main(**interface_args) -> tuple:
    action_type = interface_args[const.MAINARG_ACTION]
    plan_file = interface_args[const.MAINARG_PLANFILE]

    task_type = interface_args.get(const.MAINARG_TASK_TYPE)
    max_retries = interface_args.get(const.MAINARG_RETRY_COUNT, const.DEFAULT_RETRY_COUNT)
    retry_delay = interface_args.get(const.MAINARG_RETRY_DELAY, const.DEFAULT_RETRY_DELAY)
    fancy_logs = interface_args.get(const.MAINARG_FANCY_LOGS, const.DEFAULT_FANCY_LOGS)

    mock_dms = interface_args.get(const.DEBUG_MAINARG_MOCK_DMS) or False
    injected_dms_connection = interface_args.get(const.DEBUG_INJECTED_DMS_CONNECTION) or None

    dms_connection = injected_dms_connection or mock_dms_client(enabled=mock_dms)(aws_utils.get_dms_client)()

    action_func = ACTION_MAP[action_type]
    task_finder = TASK_FINDER_MAP[action_type]

    action_kwargs = {
        const.KEY_DMS_CONNECTION: dms_connection
    }

    task_finder_kwargs = {
        const.KEY_DMS_CONNECTION: dms_connection,
        const.MAINARG_ACTION: action_type,
        const.MAINARG_PLANFILE: plan_file,
    }

    if action_type in {const.ACTION_START, const.ACTION_START_ALL}:
        action_kwargs[const.START_ARG_TASK_TYPE] = task_type

    if action_type in {const.ACTION_STOP, const.ACTION_STOP_ALL}:
        pass

    retry_wrapped_action_func = retry_failed(
        max_attempts=max_retries,
        retry_delay=retry_delay,
        log_statuses=True
    )(action_func)

    tasks = task_finder(**task_finder_kwargs)

    action_successes, action_failures = retry_wrapped_action_func(
        tasks=tasks,
        **action_kwargs
    )

    # wrapping logging actions in a closure to avoid copy-pasting the logic twice
    def log_successes():
        logger.info(
            pprint.pformat(
                action_successes,
                width=const.LOG_SEPARATOR_LENGTH
            )
        )

    def log_errors():
        logger.error(
            pprint.pformat(
                action_failures,
                width=const.LOG_SEPARATOR_LENGTH
            )
        )

    if fancy_logs:
        logger.info("\n" + " Total Successes: ".center(const.LOG_SEPARATOR_LENGTH, "+"))
        log_successes()
        logger.info("".center(const.LOG_SEPARATOR_LENGTH, "+"))

        logger.error("\n" + " Total Errors: ".center(const.LOG_SEPARATOR_LENGTH, "*"))
        log_errors()
        logger.error("".center(const.LOG_SEPARATOR_LENGTH, "*"))

    else:
        log_successes()
        log_errors()

    return action_successes, action_failures


if __name__ == "__main__":
    cli_args = read_cli()
    main(**cli_args)

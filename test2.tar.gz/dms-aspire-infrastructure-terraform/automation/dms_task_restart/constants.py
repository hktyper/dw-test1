import enum
import os


# structural
APP_ROOT = os.path.dirname(__file__)
LOG_SEPARATOR_LENGTH = 40


@enum.unique
class ReplicationTaskType(enum.Enum):
    START = "start-replication"
    RESUME = "resume-processing"
    RELOAD = "reload-target"


# available action types
ACTION_START = "start"
ACTION_STOP = "stop"
ACTION_START_ALL = "start_all"
ACTION_STOP_ALL = "stop_all"


# main() keyword argument keys
MAINARG_ACTION = "action_type"
MAINARG_PLANFILE = "plan_file"
MAINARG_TASK_TYPE = "task_type"
MAINARG_RETRY_COUNT = "retry_count"
MAINARG_RETRY_DELAY = "retry_delay"
MAINARG_FANCY_LOGS = "fancy_logs"


# internal interfaces
KEY_REPLICATION_TASK_ARN = "replication_task_arn"
KEY_DMS_CONNECTION = "dms_connection"
START_ARG_TASK_TYPE = "task_type"

# external interfaces
AWS_CLIENT_DMS = "dms"
AWS_DMS_KEY_REPLICATION_TASKS = "ReplicationTasks"
AWS_DMS_KEY_REPLICATION_TASK_IDENTIFIER = "ReplicationTaskIdentifier"
AWS_DMS_KEY_REPLICATION_TASK_ARN = "ReplicationTaskArn"


# defaults
DEFAULT_RETRY_COUNT = 0
DEFAULT_RETRY_DELAY = 5  # seconds
DEFAULT_TASK_KEY = "tasks"
DEFAULT_TASK_TYPE = ReplicationTaskType.RESUME.value
DEFAULT_FANCY_LOGS = False

# debug
DEBUG_MODE = bool(os.environ.get('DMS_DEBUG_ENABLED' or 'False'))

DEBUG_MAINARG_MOCK_DMS = "mock_dms"
DEBUG_INJECTED_DMS_CONNECTION = "injected_dms_connection"

import argparse

from automation.dms_task_restart import constants as restart_const


def setup_cli(debug_mode=None):
    _debug_mode = restart_const.DEBUG_MODE if debug_mode is None else debug_mode
    parser = argparse.ArgumentParser()

    parser.add_argument(
        type=str,
        dest=restart_const.MAINARG_ACTION,
        help=f"Action to perform on the tasks, e.g. `{restart_const.ACTION_START}` or `{restart_const.ACTION_STOP}`."
    )

    parser.add_argument(
        "-p",
        "--plan",
        type=str,
        nargs=argparse.OPTIONAL,
        dest=restart_const.MAINARG_PLANFILE,
        help=(
            "Terraform Plan file in a human-readable format (as output by `terraform show`)."
            "NOTE: REQUIRED, but only for certain actions, "
            f"e.g. `{restart_const.ACTION_START}` or `{restart_const.ACTION_STOP}`."
        )
    )

    parser.add_argument(
        "-t",
        "--task_type",
        default=restart_const.DEFAULT_TASK_TYPE,
        type=str,
        nargs="?",
        dest=restart_const.MAINARG_TASK_TYPE,
        help=(
            "Replication Task Type for started tasks (if any). Default: `{default}`. Options: {opts}."
            .format(
                opts=[task_type.value for task_type in restart_const.ReplicationTaskType],
                default=restart_const.DEFAULT_TASK_TYPE
            )
        )
    )

    parser.add_argument(
        "-r",
        "--retries",
        type=int,
        nargs="?",
        default=restart_const.DEFAULT_RETRY_COUNT,
        dest=restart_const.MAINARG_RETRY_COUNT,
        help=(
            "Maximum number of retry rounds for failed task start/stop attempts. Default: `{default}`."
            .format(
                default=restart_const.DEFAULT_RETRY_COUNT
            )
        )
    )

    parser.add_argument(
        "--delay",
        type=int,
        nargs="?",
        default=restart_const.DEFAULT_RETRY_DELAY,
        dest=restart_const.MAINARG_RETRY_DELAY,
        help=(
            "Time between the retries. May be modified by a backoff strategy. Default: `{default}s`."
            .format(
                default=restart_const.DEFAULT_RETRY_DELAY
            )
        )
    )

    parser.add_argument(
        "--fancy_logs",
        action="store_true",
        dest=restart_const.MAINARG_FANCY_LOGS,
        help="If set, makes the logs a bit prettier, at the cost of complicating aggregation."
    )

    if _debug_mode:
        parser.add_argument(
            "--mock_dms",
            action="store_true",
            default=False,
            dest=restart_const.DEBUG_MAINARG_MOCK_DMS,
            help=(
                "DEBUG: If set, mocks out the DMS connection. Default: `{default}`."
                .format(default=False)
            )
        )

    return parser


def read_cli(preexisting_parser=None):
    parser = preexisting_parser or setup_cli()
    known, unknown = parser.parse_known_args()
    return vars(known)

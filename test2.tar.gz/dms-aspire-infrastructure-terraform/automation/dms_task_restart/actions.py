import typing

from automation.dms_task_restart import aws_utils
from automation.dms_task_restart import constants as const
from automation.read_terraform_plan import read_plan


def stop_tasks(
        tasks: dict,
        dms_connection: typing.Optional[object] = None,
        **stop_task_kwargs
) -> typing.Tuple[dict, dict]:

    successful = {}
    failed = {}
    pending = tasks.copy()
    dms_client = dms_connection or aws_utils.get_dms_client()

    while pending:
        task_name, task = pending.popitem()
        stop_response = None
        try:
            task_arn = task.get(const.KEY_REPLICATION_TASK_ARN, NotImplemented)
            # The task_arn is required, but letting it fail in the dms_client instead of in the
            # dict lookup makes it easier to track successes/failures when using a mock client
            stop_response = dms_client.stop_replication_task(ReplicationTaskArn=task_arn, **stop_task_kwargs)
        except Exception as E:
            failed[task_name] = failed.get(task_name, []) + [E]
        else:
            successful[task_name] = stop_response

    return successful, failed


def start_tasks(
        tasks: dict,
        dms_connection: typing.Optional[object] = None,
        **start_task_kwargs
) -> typing.Tuple[dict, dict]:

    successful = {}
    failed = {}
    pending = tasks.copy()
    dms_client = dms_connection or aws_utils.get_dms_client()

    while pending:
        task_name, task = pending.popitem()
        start_response = None
        try:
            task_arn = task.get(const.KEY_REPLICATION_TASK_ARN, NotImplemented)
            # The task_arn is required, but letting it fail in the dms_client instead of in the
            # dict lookup makes it easier to track successes/failures when using a mock client
            start_response = dms_client.start_replication_task(
                ReplicationTaskArn=task_arn,
                StartReplicationTaskType=start_task_kwargs[const.START_ARG_TASK_TYPE]
            )
        except Exception as E:
            failed.setdefault(task_name, []).append(E)
        else:
            successful[task_name] = start_response

    return successful, failed


def plan_task_finder(**kwargs) -> dict:
    action_type = kwargs[const.MAINARG_ACTION]
    plan_file = kwargs[const.MAINARG_PLANFILE]

    action_keys = ACTION_KEY_MAP[action_type]
    tasks = read_plan.get_tasks(action_keys=action_keys, plan_file=plan_file)
    return tasks


def aws_task_finder(**kwargs):
    dms_client = kwargs.get(const.KEY_DMS_CONNECTION) or aws_utils.get_dms_client()
    tasks = aws_utils.get_all_tasks(dms_connection=dms_client)
    return tasks


ACTION_MAP = {
    const.ACTION_START: start_tasks,
    const.ACTION_STOP: stop_tasks,
    const.ACTION_START_ALL: start_tasks,
    const.ACTION_STOP_ALL: stop_tasks,
}

TASK_FINDER_MAP = {
    const.ACTION_START: plan_task_finder,
    const.ACTION_STOP: plan_task_finder,
    const.ACTION_START_ALL: aws_task_finder,
    const.ACTION_STOP_ALL: aws_task_finder,
}

ACTION_KEY_MAP = {
    const.ACTION_START: read_plan.const.KEYS_START_ACTION,
    const.ACTION_STOP: read_plan.const.KEYS_STOP_ACTION,
}

import sys
import logging


def setup_logs(level=logging.INFO):
    logger = logging.getLogger(__file__)

    logger.setLevel(level=level)

    stdout_handler = logging.StreamHandler(stream=sys.stdout)

    formatter = logging.Formatter(
        " - ".join(
            (
                "%(asctime)s",
                "%(filename)s",
                "%(funcName)s",
                "%(levelname)s",
                "%(message)s"
            )
        )
    )
    stdout_handler.setFormatter(formatter)

    for handler in {stdout_handler}:
        logger.addHandler(handler)

    return logger


logger = setup_logs()

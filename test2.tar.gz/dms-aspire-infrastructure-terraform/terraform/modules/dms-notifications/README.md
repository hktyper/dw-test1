## Providers

| Name | Version |
|------|---------|
| aws | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:-----:|
| account\_id | AWS Account ID | `string` | n/a | yes |
| artifact\_s3\_bucket | Bucket to obtain Lambda code from | `string` | n/a | yes |
| default\_tags | Default project tags. | `map(string)` | `{}` | no |
| environment | Target environment - [dev, preprod, prod] | `string` | `"dev"` | no |
| lambda\_code\_prefix | S3 prefix of the Lambda function code | `string` | `"lambda-functions"` | no |
| lambda\_package\_name | Name of the Python package to create the Lambda from. Expects to find this as a zip file in <lambda\_code\_prefix> | `string` | n/a | yes |
| s3\_notification\_topic\_arns | A list of SNS ARNs that the notification enricher lambda should subscribe to | `list(string)` | `[]` | no |
| subscriber\_arns | A list of roles or accounts that need to subscribe to the notifications topic | `list(string)` | `[]` | no |

## Outputs

| Name | Description |
|------|-------------|
| sns\_topic\_arn | ARN of the SNS topic notifications are published to |


## Providers

| Name | Version |
|------|---------|
| aws | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:-----:|
| default\_tags | Default project tags. | `map(string)` | `{}` | no |
| environment |  | `string` | n/a | yes |
| task_config | Task config, as loaded from a local file. | `bool` | n/a | yes |
| replication_subnet_group_id | Subnet group associated with the replication instance. | `string` | n/a | yes |
| source_endpoint_arn_map | A map of the endpoint ARNs created for the source databases, with the source database name being the key (e.g. hddw) | `map(string)` | n/a | yes |
| target_endpoint_arn_map | A map of the endpoint ARNs created for the target buckets, with the bucket name being the key. | `map(string)` | n/a | yes |


## Outputs

No outputs.
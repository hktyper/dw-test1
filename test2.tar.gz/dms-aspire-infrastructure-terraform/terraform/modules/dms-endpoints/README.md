## Providers

| Name | Version |
|------|---------|
| aws | n/a |
| null | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:-----:|
| default\_tags | Default project tags. | `map(string)` | `{}` | no |
| dms\_target\_engine | The type of engine for the endpoint. | `string` | n/a | yes |
| environment | The environment the DMS will be deployed in (e.g. dev/pre-prod/prod) | `string` | n/a | yes |
| prefix | Environment and project name | `string` | n/a | yes |
| service\_access\_role\_arn\_map | A map of the ARNs of the IAM Roles with permissions to read from or write to the S3 Bucket. | `map(string)` | n/a | yes |
| source\_binary\_reader | Use the binary log reader for source endpoints | `map(bool)` | n/a | yes |
| source\_dbs | Set of human-readable abbreviations for the source systems | `set(string)` | n/a | yes |
| source\_dbs\_defs | A unique list of mappings of source dbs, the data classification type (pii/non-pii), and bucket names | `list(map(string))` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| source\_endpoint\_arn\_map | A map of the endpoint ARNs created for the source databases, with the source database name being the key (e.g. hddw) |
| target\_endpoint\_arn\_map | A map of the endpoint ARNs created for the target buckets, with the bucket name being the key |


## Providers

| Name | Version |
|------|---------|
| aws | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:-----:|
| environment | The environment the DMS will be deployed in (e.g. dev/pre-prod/prod). | `string` | n/a | yes |
| default\_tags | Default project tags. | `map(string)` | `{}` | no |
| prefix | Environment and project name. | `string` | n/a | yes |
| create_roles | Boolean to indicate whether or not to create IAM roles for VPC and CloudWatch (environment specific) | `bool` | n/a | yes |
| subnet_ids | Subnet IDs for the DMS Endpoints. | `list(string)` | n/a | yes |
| source_dbs_defs | A unique list of mappings of source dbs, the data classification type (pii/non-pii), and bucket names. | `set(map(string))` | n/a | yes |
| dms_target_engine | The type of engine for the endpoint. | `string` | n/a | yes |
| dms\_mgmt\_policy\_arn | DMS management policy attached to VPC role. | `string` | `"arn:aws:iam::aws:policy/service-role/AmazonDMSVPCManagementRole"` | no |
| dms\_cw\_policy\_arn | CloudWatch policy attached to DMS role. | `string` | `"arn:aws:iam::aws:policy/service-role/AmazonDMSCloudWatchLogsRole"` | no |


## Outputs

| Name | Description | Type |
|------|-------------|------|
| dms_s3_role_arn_map | A map of the endpoint ARNs created for the S3 IAM roles, with the bucket name being the key | `map(string)` |
| dms_subnet_group_id | Replication subnet group ID | `string` |

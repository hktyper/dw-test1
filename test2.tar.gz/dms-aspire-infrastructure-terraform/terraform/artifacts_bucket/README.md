## Providers

| Name | Version |
|------|---------|
| aws | ~> 3.0 |

## Purpose

This creates an S3 bucket to use as a repository for Lambda code artifacts. It's referred to in the main stack
so this needs to be run first. The actual Lambda code will be created via a different pipeline and can be assumed
to exist when running the main stack.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:-----:|
| audit\_s3\_access\_logs\_bucket | S3 Bucket to send access logs to | `map(string)` | n/a | yes |
| costcentre | The name of the costcentre | `string` | `"PD7455"` | no |
| email | The email of the owner | `string` | `"natalie.smith@sainsburys.co.uk"` | no |
| environment | The environment the stack is going to be deployed in e.g. dev/test/preprod/prod | `map(string)` | n/a | yes |
| live | live. in non prod it is a no | `map(string)` | n/a | yes |
| owner | The owner of the resources that will be created | `string` | `"Natalie Smith"` | no |
| project | project name | `string` | `"grada-apple"` | no |
| region | AWS region where the stack will be deployed. | `map(string)` | n/a | yes |
| stack | stack name | `string` | `"dms-artifacts"` | no |
| technical\_contact | technical contact for dms poc project | `string` | `"gdp_apple@sainsburys.co.uk"` | no |

## Outputs

No output.


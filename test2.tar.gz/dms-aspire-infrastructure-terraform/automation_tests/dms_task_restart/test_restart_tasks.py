import argparse
import os
from unittest import mock

import pytest

from automation.dms_task_restart import aws_utils
from automation.dms_task_restart import constants as const
from automation.dms_task_restart import decorators as decos
from automation.dms_task_restart import cli
from automation.dms_task_restart import restart_tasks
from automation_tests import constants as test_const

PLAN_UPDATE = os.path.join(test_const.TEST_DIR, "deployment-dev-update-tasks.json")
PLAN_CREATE = os.path.join(test_const.TEST_DIR, "deployment-dev-creating-tasks.json")

EXPECTED_STOPS = {
    (const.ACTION_STOP, PLAN_UPDATE): 2,
    (const.ACTION_STOP, PLAN_CREATE): 0,
    (const.ACTION_START, PLAN_UPDATE): 2,
    (const.ACTION_START, PLAN_CREATE): 2,
}

EXPECTED_STARTS = {
    (const.ACTION_STOP, PLAN_UPDATE): 0,
    (const.ACTION_STOP, PLAN_CREATE): 0,
    (const.ACTION_START, PLAN_UPDATE): 2,
    (const.ACTION_START, PLAN_CREATE): 2,
}

RETRY_TEST_RANGE = (1, 2)  # i.e. range(0, 2) on runtime


def test_cli_prod():
    parser = cli.setup_cli(debug_mode=False)
    assert parser
    assert isinstance(parser, argparse.ArgumentParser)
    known_args, unknown_args = parser.parse_known_args(
        args=[const.ACTION_STOP, f'--plan={test_const.TEST_PLAN_FILE}', "--mock_dms"]
    )

    assert known_args
    app_args = vars(known_args)
    assert app_args
    assert const.MAINARG_PLANFILE in app_args
    assert app_args[const.MAINARG_PLANFILE] == test_const.TEST_PLAN_FILE
    assert const.DEBUG_MAINARG_MOCK_DMS not in app_args


def test_cli_debug():
    parser = cli.setup_cli(debug_mode=True)
    assert parser
    known_args, unknown_args = parser.parse_known_args(
        args=[const.ACTION_STOP, f'--plan={test_const.TEST_PLAN_FILE}', "--mock_dms"]
    )
    assert known_args
    app_args = vars(known_args)
    assert app_args
    assert const.MAINARG_PLANFILE in app_args
    assert app_args[const.MAINARG_PLANFILE] == test_const.TEST_PLAN_FILE
    assert const.DEBUG_MAINARG_MOCK_DMS in app_args
    assert app_args[const.DEBUG_MAINARG_MOCK_DMS] is True


def build_dms_failure_mock():
    stop_task_mock = mock.Mock(side_effect=RuntimeError('Mock Exception!'))
    start_task_mock = mock.Mock(side_effect=RuntimeError('Mock Exception!'))
    mock_connection = mock.MagicMock(name='failure_dms_mock')
    mock_connection.stop_replication_task = stop_task_mock
    mock_connection.start_replication_task = start_task_mock
    return mock_connection


def _with_mock_dms_deco_tester(action, plan_file, mock_connection, retry_count, expected_successes, expected_failures):
    parser = cli.setup_cli(debug_mode=False)
    known_args, _ = parser.parse_known_args(
        args=[action, plan_file, f"--retries={retry_count}"]
    )
    run_args = vars(known_args)
    run_args[const.DEBUG_INJECTED_DMS_CONNECTION] = mock_connection

    run_results = restart_tasks.main(**run_args)

    assert run_results
    assert len(run_results) == 2

    actual_successes, actual_failures = run_results
    assert isinstance(actual_successes, dict)
    assert isinstance(actual_failures, dict)
    assert len(actual_successes) == expected_successes
    assert len(actual_failures) == expected_failures

    tested_method_map = {
        const.ACTION_START: mock_connection.start_replication_task,
        const.ACTION_STOP: mock_connection.stop_replication_task
    }

    tested_method = tested_method_map[action]
    assert tested_method.call_count == (
            (expected_failures * retry_count)
            + (
                # If the task is expected to finish successfully...
                expected_successes if expected_successes > 0
                # ...or if it's just going to fail until it gives up.
                else expected_failures
            )
    )


@pytest.mark.parametrize(
    "action, plan_file, mock_connection, retry_count, expected_successes, expected_failures",
    [
        # - #  standard CLI debug mock  # - #
        (
                const.ACTION_STOP,
                f'--plan={PLAN_UPDATE}',  # plan file
                decos.mock_dms_client(enabled=True)(aws_utils.get_dms_client)(),
                retry_count,
                EXPECTED_STOPS[const.ACTION_STOP, PLAN_UPDATE],  # successful actions
                0,  # failed actions
        )
        for retry_count in range(*RETRY_TEST_RANGE)
    ]
)
def test_update_stop_success(action, plan_file, mock_connection, retry_count, expected_successes, expected_failures):
    _with_mock_dms_deco_tester(action, plan_file, mock_connection, retry_count, expected_successes, expected_failures)


@pytest.mark.parametrize(
    "action, plan_file, mock_connection, retry_count, expected_successes, expected_failures",
    [
        # - #  standard CLI debug mock  # - #
        (
                const.ACTION_START,
                f'--plan={PLAN_UPDATE}',  # plan file
                decos.mock_dms_client(enabled=True)(aws_utils.get_dms_client)(),
                retry_count,
                EXPECTED_STARTS[const.ACTION_START, PLAN_UPDATE],  # successful actions
                0,  # failed actions
        )
        for retry_count in range(*RETRY_TEST_RANGE)
    ]
)
def test_update_start_success(action, plan_file, mock_connection, retry_count, expected_successes, expected_failures):
    _with_mock_dms_deco_tester(action, plan_file, mock_connection, retry_count, expected_successes, expected_failures)


@pytest.mark.parametrize(
    "action, plan_file, mock_connection, retry_count, expected_successes, expected_failures",
    [
        (
                const.ACTION_STOP,
                f'--plan={PLAN_UPDATE}',  # plan file
                build_dms_failure_mock(),  # connection
                retry_count,
                0,
                EXPECTED_STOPS[const.ACTION_STOP, PLAN_UPDATE],  # successful actions
        )
        for retry_count in range(*RETRY_TEST_RANGE)
    ]
)
def test_update_stop_failure(action, plan_file, mock_connection, retry_count, expected_successes, expected_failures):
    _with_mock_dms_deco_tester(action, plan_file, mock_connection, retry_count, expected_successes, expected_failures)


@pytest.mark.parametrize(
    "action, plan_file, mock_connection, retry_count, expected_successes, expected_failures",
    [
        (
                const.ACTION_START,
                f'--plan={PLAN_UPDATE}',  # plan file
                build_dms_failure_mock(),  # connection
                retry_count,
                0,
                EXPECTED_STARTS[const.ACTION_START, PLAN_UPDATE],  # successful actions
        )
        for retry_count in range(*RETRY_TEST_RANGE)
    ]
)
def test_update_start_failure(action, plan_file, mock_connection, retry_count, expected_successes, expected_failures):
    _with_mock_dms_deco_tester(action, plan_file, mock_connection, retry_count, expected_successes, expected_failures)


@pytest.mark.parametrize(
    "action, plan_file, mock_connection, retry_count, expected_successes, expected_failures",
    [
        (
                const.ACTION_STOP,
                f'--plan={PLAN_CREATE}',  # plan file
                decos.mock_dms_client(enabled=True)(aws_utils.get_dms_client)(),  # connection
                retry_count,
                EXPECTED_STOPS[const.ACTION_STOP, PLAN_CREATE],  # successful actions
                0,
        )
        for retry_count in range(*RETRY_TEST_RANGE)
    ]
)
def test_create_stop_success(action, plan_file, mock_connection, retry_count, expected_successes, expected_failures):
    _with_mock_dms_deco_tester(action, plan_file, mock_connection, retry_count, expected_successes, expected_failures)


@pytest.mark.parametrize(
    "action, plan_file, mock_connection, retry_count, expected_successes, expected_failures",
    [
        (
                const.ACTION_START,
                f'--plan={PLAN_CREATE}',  # plan file
                decos.mock_dms_client(enabled=True)(aws_utils.get_dms_client)(),  # connection
                retry_count,
                EXPECTED_STARTS[const.ACTION_START, PLAN_CREATE],  # successful actions
                0
        )
        for retry_count in range(*RETRY_TEST_RANGE)
    ]
)
def test_create_start_success(action, plan_file, mock_connection, retry_count, expected_successes, expected_failures):
    _with_mock_dms_deco_tester(action, plan_file, mock_connection, retry_count, expected_successes, expected_failures)


@pytest.mark.parametrize(
    "action, plan_file, mock_connection, retry_count, expected_successes, expected_failures",
    [
        (
                const.ACTION_STOP,
                f'--plan={PLAN_CREATE}',  # plan file
                build_dms_failure_mock(),  # connection
                retry_count,
                0,
                EXPECTED_STOPS[const.ACTION_STOP, PLAN_CREATE],  # successful actions
        )
        for retry_count in range(*RETRY_TEST_RANGE)
    ]
)
def test_create_stop_failure(action, plan_file, mock_connection, retry_count, expected_successes, expected_failures):
    _with_mock_dms_deco_tester(action, plan_file, mock_connection, retry_count, expected_successes, expected_failures)


@pytest.mark.parametrize(
    "action, plan_file, mock_connection, retry_count, expected_successes, expected_failures",
    [
        (
                const.ACTION_START,
                f'--plan={PLAN_CREATE}',  # plan file
                build_dms_failure_mock(),  # connection
                retry_count,
                0,
                EXPECTED_STARTS[const.ACTION_START, PLAN_CREATE],  # successful actions
        )
        for retry_count in range(*RETRY_TEST_RANGE)
    ]
)
def test_create_start_failure(action, plan_file, mock_connection, retry_count, expected_successes, expected_failures):
    _with_mock_dms_deco_tester(action, plan_file, mock_connection, retry_count, expected_successes, expected_failures)


if __name__ == '__main__':
    pytest.main([__file__])

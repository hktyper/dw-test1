import os

TEST_DIR = os.path.dirname(__file__)

TEST_PLAN_FILE_NAME = "deployment-dev-update-tasks.json"
TEST_PLAN_FILE = os.path.join(TEST_DIR, TEST_PLAN_FILE_NAME)

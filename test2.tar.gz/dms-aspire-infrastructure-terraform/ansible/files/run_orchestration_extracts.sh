#!/bin/bash
DEPLOY_ENV=$1
SCRIPT_HOME=$2
CONFIG_FILE=$3
DATE_FORMAT="%Y-%m-%d %H:%M:%S"
LOG_FILE_DATE_FORMAT="%Y-%m-%d"

function run_job() {
  nohup pipenv run python -m orchestrator --config-file=${CONFIG_FILE} \
    >>${SCRIPT_HOME}/logs/${DEPLOY_ENV}-orchestrator-$(date +"${LOG_FILE_DATE_FORMAT}").log 2>&1 &
  JOB_PID=$!
  echo -e "$(date +"$DATE_FORMAT") Job submitted as pid ${JOB_PID}"
}
cd ${SCRIPT_HOME}
echo -e "$(date +"${DATE_FORMAT}") Submitting jobs..."
run_job
echo -e "$(date +"${DATE_FORMAT}") All jobs submitted"

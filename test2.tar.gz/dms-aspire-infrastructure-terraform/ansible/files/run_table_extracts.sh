#!/bin/bash

DEPLOY_ENV=$1
SCRIPT_HOME=$2
DATE_FORMAT="%Y-%m-%d %H:%M:%S"
LOG_FILE_DATE_FORMAT="%Y-%m-%d"

case $DEPLOY_ENV in
  prod)
    BUCKET_PREFIX="dpp2-prd"
    ;;
  preprod)
    BUCKET_PREFIX="dpp-preprd"
    ;;
  *)
    BUCKET_PREFIX="dpp-${DEPLOY_ENV}"
    ;;
esac

function run_job() {
  DB=$1
  SCHEMA=$2
  TABLE=$3
  PII_COLS=$4
  HWM_COLUMN=$5

  if [[ $DB == "hddw" && $DEPLOY_ENV != "prod" ]]; then
    SCHEMA="dbat"
  fi

  echo -e "$(date +"$DATE_FORMAT") Submitting job for ${SCHEMA}.${TABLE}..."
  nohup pipenv run python -m db_extractor ${SCHEMA} ${TABLE} --prefix=csv-extracts \
    -s ${DEPLOY_ENV}/${DB} \
    -b ${BUCKET_PREFIX}-raw-src-argos-dwh-${DB} \
    -e ${PII_COLS} \
    -ht ${DEPLOY_ENV}-dms-alternative-high-watermarks \
    -hc ${HWM_COLUMN} \
    --headers  \
    >>${SCRIPT_HOME}/logs/${DEPLOY_ENV}-${SCHEMA}-${TABLE}-$(date +"${LOG_FILE_DATE_FORMAT}").log 2>&1 &
  JOB_PID=$!
  echo -e "$(date +"$DATE_FORMAT") Job submitted as pid ${JOB_PID}"
}

cd ${SCRIPT_HOME}

echo -e "$(date +"${DATE_FORMAT}") Submitting jobs..."

run_job "hddw" "dbap" "adrloc" "LCN_STORE_AREA_MGR_NM" "MIS_RECORD_MODIFY_DATE"
run_job "hddw" "dbap" "adritm" "PRIMARY_SUPPLIER_NAME BUYER_NAME" "MIS_RECORD_MODIFY_DATE"

echo -e "$(date +"${DATE_FORMAT}") All jobs submitted"
